import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mongoose, { Mongoose } from 'mongoose';

import User from './models/user';

const app = express();
const router = express.Router();

app.use(cors());
app.use(bodyParser.json());

mongoose.connect("mongodb://127.0.0.1:27017/users", {useNewUrlParser: true, useUnifiedTopology: true});
const connection = mongoose.connection;

connection.once('open', () => {
    console.log("Database online.");
});

router.route('/users').get((req,res) => {
    User.find((err,users) => {
        if (err)
            console.log(err);
        else {
            res.json(users);
            console.log(users);
            console.log("Displayed.");
        }
    })
})

router.route('/users/add').post((req,res) => {
    let user = new User(req.body);
    console.log(user);
    user.save()
        .then(user => {
            res.status(200).json({'User': 'Added Successfully'});
        })
        .catch(err => {
            res.status(400).send('Failed to create new record');
        });
});

app.use('/', router);
app.listen(4000, () => console.log('Express up and running'));