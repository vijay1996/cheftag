import { Component, OnInit } from '@angular/core';

import { UserService } from '../../user.service';
import { User } from '../../user.model'; 

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  name: string = "";
  email: string = "";
  password: string = "";
  
  constructor(private userService: UserService) { }

  ngOnInit() {
  }
  
  addUser() {
    console.log(this.name,this.email,this.password);
    this.userService.addUser(this.name,this.email,this.password);
  }

}
