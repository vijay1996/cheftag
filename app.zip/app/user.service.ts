import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  uri:string = 'http://localhost:4000';

  constructor( private http: HttpClient ) { }
  
  getUsers() {
    console.log("get users pe hai")
    return this.http.get(`${this.uri}/users`);
  }

  addUser(name,email,password) {
    const user = {
      name: name,
      email: email,
      password: password
    }
    console.log(user);
    return this.http.post(`${this.uri}/users/add`, user)
      
  }

}
