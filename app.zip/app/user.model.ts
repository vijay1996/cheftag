export interface User {
    name: String;
    email: String;
    password: String;
}