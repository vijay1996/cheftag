import mongoose from 'mongoose';

const Schema = mongoose.Schema;

let Issue = new Schema({
    title: {
        type: String,
        default: "cool"
    },
    responsible: {
        type: String,
        default: "cool"
    },
    description: {
        type: String,
        default: "cool"
    },
    severity: {
        type: String,
        default: "cool"
    },
    status: {
        type: String,
        default: 'Open'
    },
    name: {
        type: String
    }
});

export default mongoose.model('Issue', Issue);